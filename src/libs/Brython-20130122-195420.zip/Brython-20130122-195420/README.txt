To test the package, open the file test.html in a browser
You should see a digital clock and the Brython version number

If everything works, you are ready to use Brython. Have fun !